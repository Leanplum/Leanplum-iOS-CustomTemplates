//
//  ListTableViewCell.m
//  CustomTemplatesExample
//
//  Created by Nikola Zagorchev on 16.06.20.
//  Copyright © 2020 Nikola Zagorchev. All rights reserved.
//

#import "ListTableViewCell.h"

@implementation ListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    // Adjust the frame to respect the padding
    self.imageView.frame = CGRectMake(0, self.padding, self.frame.size.width/3, self.frame.size.height - self.padding*2);
    self.textLabel.frame = CGRectMake(self.frame.size.width/3 + self.padding, self.padding, (self.frame.size.width/3)*2 - self.padding, self.frame.size.height - self.padding*2);
}

@end
