//
//  PromoItem.h
//  CustomTemplatesExample
//
//  Created by Nikola Zagorchev on 16.06.20.
//  Copyright © 2020 Nikola Zagorchev. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PromoItem : NSObject
@property NSNumber *priceOld;
@property NSNumber *priceNew;
@property NSString *headerText;
@property UIColor *headerColor;
@property NSArray *items;
@property NSString *listItemPath;
@property int padding;
@property int rowHeight;
@property NSString *buttonText;
@end

NS_ASSUME_NONNULL_END
