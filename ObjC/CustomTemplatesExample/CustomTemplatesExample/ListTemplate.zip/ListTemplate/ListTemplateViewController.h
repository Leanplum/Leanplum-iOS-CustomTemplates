//
//  ListTemplateViewController.h
//  CustomTemplatesExample
//
//  Created by Nikola Zagorchev on 15.06.20.
//  Copyright © 2020 Nikola Zagorchev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Leanplum.h"
#import "PromoItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface ListTemplateViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UILabel *headerLabel;

@property (weak, nonatomic) IBOutlet UILabel *priceOldLabel;

@property (weak, nonatomic) IBOutlet UILabel *priceNewLabel;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UIButton *actionBtn;

+ (nullable ListTemplateViewController*) initWithPromoItem:(PromoItem *)item;
@end

NS_ASSUME_NONNULL_END
