//
//  ListTemplate.m
//  CustomTemplatesExample
//
//  Created by Nikola Zagorchev on 15.06.20.
//  Copyright © 2020 Nikola Zagorchev. All rights reserved.
//

#import "ListTemplate.h"
#import <Foundation/Foundation.h>
#import "Leanplum/Leanplum.h"
#import "ListTemplateViewController.h"
#import "PromoItem.h"

@implementation ListTemplate

#pragma mark - Arguments
static NSString * const AcceptActionArg = @"Accept action";
static NSString * const AcceptStr = @"Accept";

+ (void)defineAction {
    
    BOOL (^messageResponder)(LPActionContext *) = ^(LPActionContext *context) {
        if ([context hasMissingFiles]) {
            return NO;
        }
        
        // Access the items - returns the items defined in the message
        NSDictionary *items = [context dictionaryNamed:@"List Items"];
        
        
        
        @try {
           //#### example here you can present however you want.
            //We are dispalying simple alert view with 3 buttons over top view controller
           UIViewController *topController = [UIApplication sharedApplication].keyWindow.rootViewController;
           while (topController.presentedViewController) {
               topController = topController.presentedViewController;
           }
            [topController presentViewController:[ListTemplate viewControllerWithContext:context] animated:YES completion:nil];
            return YES;
        }
        @catch (NSException *exception) {
            //#### example Log excepation
            return NO;
        }
    };
    
    NSString *defaultItemText = @"list item text";
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:defaultItemText, @"list item 1", defaultItemText, @"list item 2", nil];
    NSString *headerGroup = @"Header";
    
    [Leanplum defineAction:@"List Template"
                    ofKind:kLeanplumActionKindMessage
             withArguments:@[
                 [LPActionArg argNamed:[NSString stringWithFormat:@"%@.%@",headerGroup, @"Text"] withString:@""],
                 [LPActionArg argNamed:[NSString stringWithFormat:@"%@.%@",headerGroup, @"Text Color"] withColor:UIColor.blackColor],
                 [LPActionArg argNamed:AcceptStr withString:AcceptStr],
                 [LPActionArg argNamed:AcceptActionArg withAction:nil],
                 [LPActionArg argNamed:@"Price.Old Price" withNumber:[NSNumber numberWithInteger:0]],
                 [LPActionArg argNamed:@"Price.Promo Price" withNumber:[NSNumber numberWithInteger:0]],
                 [LPActionArg argNamed:@"List Style Image" withFile:nil],
                 [LPActionArg argNamed:@"List Items" withDict:dict]]
             withResponder:messageResponder];
}

+ (NSString *)getArgNameWithGroup:(NSString *)group withName:(NSString *)argName {
    return [NSString stringWithFormat:@"%@.%@",group, argName];
}

+ (UIViewController *)viewControllerWithContext:(LPActionContext *)context
{
    PromoItem *item = [[PromoItem alloc] init];
    item.listItemPath = [context fileNamed:@"List Style Image"];
    NSDictionary *dict = [context dictionaryNamed:@"List Items"];
    item.items = [[dict.allValues reverseObjectEnumerator] allObjects];

    item.headerText = [context stringNamed:[ListTemplate getArgNameWithGroup:@"Header" withName:@"Text"]];
    item.headerColor = [context colorNamed:[ListTemplate getArgNameWithGroup:@"Header" withName:@"Text Color"]];
    
    item.priceOld = [context numberNamed:@"Price.Old Price"];
    item.priceNew = [context numberNamed:@"Price.Promo Price"];
    
    item.buttonText = [context stringNamed:AcceptStr];
    
    item.padding = 5;
    item.rowHeight = 80;
    
    ListTemplateViewController *viewController = [ListTemplateViewController initWithPromoItem:item];
    viewController.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    return viewController;
}


@end
