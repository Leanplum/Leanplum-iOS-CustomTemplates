//
//  ListTemplate.h
//  CustomTemplatesExample
//
//  Created by Nikola Zagorchev on 15.06.20.
//  Copyright © 2020 Nikola Zagorchev. All rights reserved.
//

#import "Foundation/Foundation.h"
NS_ASSUME_NONNULL_BEGIN

@interface ListTemplate : NSObject
+ (void)defineAction;
@end

NS_ASSUME_NONNULL_END
