//
//  PromoItem.m
//  CustomTemplatesExample
//
//  Created by Nikola Zagorchev on 16.06.20.
//  Copyright © 2020 Nikola Zagorchev. All rights reserved.
//

#import "PromoItem.h"

@implementation PromoItem

@end
