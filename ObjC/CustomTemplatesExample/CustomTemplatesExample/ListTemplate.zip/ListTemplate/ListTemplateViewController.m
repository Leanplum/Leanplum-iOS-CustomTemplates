//
//  ListTemplateViewController.m
//  CustomTemplatesExample
//
//  Created by Nikola Zagorchev on 15.06.20.
//  Copyright © 2020 Nikola Zagorchev. All rights reserved.
//

#import "ListTemplateViewController.h"
#import "Leanplum.h"
#import "UIKit/UIKit.h"
#import "ListTableViewCell.h"
#import "PromoItem.h"

@interface ListTemplateViewController ()
@property PromoItem* promoItem;
@end

@implementation ListTemplateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSNumberFormatter *nf = [[NSNumberFormatter alloc] init];
    [nf setNumberStyle:NSNumberFormatterCurrencyStyle];
    NSString *priceNew = [nf stringFromNumber:self.promoItem.priceNew];
    
    self.priceNewLabel.text = priceNew;
    
    NSString *priceOld = [nf stringFromNumber: self.promoItem.priceOld];
    NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc] initWithString:priceOld];
    [attributeString addAttribute:NSStrikethroughStyleAttributeName
                            value:@2
                            range:NSMakeRange(0, [attributeString length])];
    [self.priceOldLabel setAttributedText:attributeString];
    
    self.headerLabel.text = self.promoItem.headerText;
    self.headerLabel.textColor = self.promoItem.headerColor;
    self.headerLabel.numberOfLines = 0;
    [self.headerLabel sizeToFit];
    
    self.tableView.rowHeight = self.promoItem.rowHeight;

    [self.actionBtn setTitle:self.promoItem.buttonText.uppercaseString forState:UIControlStateNormal];
    [self.actionBtn setBackgroundColor:[UIColor colorWithRed:214/255.0 green:99/255.0 blue:136/255.0 alpha:1]];
    [self.actionBtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

+ (id) initWithPromoItem: (PromoItem*)item {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"ListTemplateStoryboard" bundle:nil];
    ListTemplateViewController *ctrl = [storyboard instantiateInitialViewController];
    ctrl.promoItem = item;
    return ctrl;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.promoItem.items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ListTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"listCell" forIndexPath:indexPath];
    
    cell.padding = self.promoItem.padding;
    
    NSString *rowText = self.promoItem.items[indexPath.row];
    
    [cell.textLabel setText: rowText];
    [cell.imageView setImage:[UIImage imageWithContentsOfFile:self.promoItem.listItemPath]];
    
    return cell;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
